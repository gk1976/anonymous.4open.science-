# GraphRAG-DS: A Human-Governed Framework for Persistent Knowledge Graphs

This repository contains the official supplementary code for the MethodsX protocol article: **"GraphRAG-DS: A Human-Governed Framework for Persistent Knowledge Graphs and Long-Horizon Agentic Retrieval"**.

## Overview
This protocol implements a durable, stateful agentic memory system using LangGraph and PostgreSQL. It features a **Delta-Gated Commit Protocol**, which requires Human-in-the-Loop (HITL) approval before graph mutations are committed, preventing compounding memory errors over multi-session runs.

## Structure
- `src/state_machine.py`: The core LangGraph implementation (Extraction -> HITL Interrupt -> Commit).
- `src/drift_metrics.py`: Implementation of Structural Drift (\(D_{struct}\)), Semantic Drift (\(D_{sem}\)), and Cumulative Drift Ratio (\(CDR_t\)).
- `src/entity_resolution.py`: Hybrid string-edit and embedding similarity for entity merging.
- `data/sample_ground_truth.json`: Sample ground-truth graph for drift evaluation testing.

## Quick Start (Google Colab)
You can run the entire protocol without installing anything locally by opening `GraphRAG_DS_Colab_Tutorial.ipynb` in [Google Colab](https://colab.research.google.com/).

## Local Setup
1. Clone the repository: `git clone https://github.com/your-username/GraphRAG-DS-Protocol.git`
2. Install dependencies: `pip install -r requirements.txt`
3. Ensure you have a PostgreSQL database running (for the `PostgresSaver` checkpointer). Update the `DATABASE_URL` in the configuration.

## License
This project is licensed under the MIT License - see the LICENSE file for details.