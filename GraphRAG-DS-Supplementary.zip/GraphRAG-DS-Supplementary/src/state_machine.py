%%writefile state_machine.py
import os
import psycopg
from typing import TypedDict, List, Dict, Any
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import interrupt

class KnowledgeGraphState(TypedDict):
    graph_nodes: Dict[str, Dict[str, Any]]
    graph_edges: List[Dict[str, Any]]
    proposed_deltas: Dict[str, List[Dict[str, Any]]]
    human_feedback: Dict[str, Any]
    session_id: str
    logs: List[str]

def extract_incremental_graph(state: KnowledgeGraphState) -> Dict[str, Any]:
    print(f"--- Running Extraction for Session {state['session_id']} ---")
    deltas = {
        "add_nodes": [{"id": "E_101", "label": "Oncology", "type": "Domain"}],
        "add_edges": [{"source": "E_101", "target": "E_102", "relation": "TREATS"}],
        "remove_nodes": [],
        "remove_edges": []
    }
    return {"proposed_deltas": deltas, "logs": state.get("logs", []) + ["Extraction complete"]}

def human_review_interrupt(state: KnowledgeGraphState) -> Dict[str, Any]:
    print("--- HALTING FOR HUMAN REVIEW ---")
    pending_deltas = state.get("proposed_deltas", {})
    review_decision = interrupt({
        "message": "Human review required for pending graph deltas.",
        "deltas_to_review": pending_deltas
    })
    return {"human_feedback": review_decision}

def commit_graph_state(state: KnowledgeGraphState) -> Dict[str, Any]:
    current_nodes = dict(state.get("graph_nodes", {}))
    current_edges = list(state.get("graph_edges", []))
    feedback = state.get("human_feedback", {})
    action = feedback.get("action", "approve") 
    
    print(f"--- Committing State (Action: {action}) ---")
    
    if action == "approve":
        approved_deltas = state.get("proposed_deltas", {})
        for node in approved_deltas.get("add_nodes", []):
            current_nodes[node["id"]] = node
        for edge in approved_deltas.get("add_edges", []):
            current_edges.append(edge)
    elif action == "edit":
        edited_deltas = feedback.get("edited_deltas", {})
        for node in edited_deltas.get("add_nodes", []):
            current_nodes[node["id"]] = node
        for edge in edited_deltas.get("add_edges", []):
            current_edges.append(edge)
    elif action == "reject":
        print("Action rejected. State remains unchanged.")
        pass
        
    return {
        "graph_nodes": current_nodes,
        "graph_edges": current_edges,
        "proposed_deltas": {"add_nodes": [], "add_edges": [], "remove_nodes": [], "remove_edges": []},
        "logs": state.get("logs", []) + [f"Commit action: {action}"]
    }

def build_workflow(use_postgres=False, db_uri=None):
    builder = StateGraph(KnowledgeGraphState)
    builder.add_node("extract", extract_incremental_graph)
    builder.add_node("human_review", human_review_interrupt)
    builder.add_node("commit", commit_graph_state)

    builder.set_entry_point("extract")
    builder.add_edge("extract", "human_review")
    builder.add_edge("human_review", "commit")
    builder.add_edge("commit", END)
    
    if use_postgres and db_uri:
        conn = psycopg.connect(db_uri, autocommit=True)
        checkpointer = PostgresSaver(conn)
        checkpointer.setup()
    else:
        checkpointer = MemorySaver()
        
    return builder.compile(checkpointer=checkpointer)