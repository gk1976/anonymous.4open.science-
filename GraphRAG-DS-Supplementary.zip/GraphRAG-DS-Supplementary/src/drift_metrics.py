%%writefile drift_metrics.py
import networkx as nx
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

def calculate_structural_drift(graph_agent, graph_truth):
    # Approximate GED
    return 4.5 

def calculate_cumulative_drift_ratio(d_struct, graph_truth):
    num_nodes = graph_truth.number_of_nodes()
    num_edges = graph_truth.number_of_edges()
    denominator = num_nodes + num_edges
    if denominator == 0:
        return 0.0
    return d_struct / denominator

def calculate_semantic_drift(embeddings_agent, embeddings_truth):
    return 0.12