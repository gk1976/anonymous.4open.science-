import sys
import os
# If you cloned the repo in Colab:
# !git clone https://github.com/your-username/GraphRAG-DS-Protocol.git
# sys.path.append('/content/GraphRAG-DS-Protocol')

# For this standalone tutorial, we define the state machine directly:
from state_machine import build_workflow, KnowledgeGraphState
from langgraph.types import Command