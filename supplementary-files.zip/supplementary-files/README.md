{
  "nodes": [
    {"id": "E_101", "label": "Oncology", "type": "Domain"},
    {"id": "E_102", "label": "Drug_X", "type": "Drug"},
    {"id": "E_103", "label": "Gene_Y", "type": "Gene"}
  ],
  "edges": [
    {"source": "E_101", "target": "E_102", "relation": "TREATS"},
    {"source": "E_102", "target": "E_103", "relation": "TARGETS"}
  ]
}